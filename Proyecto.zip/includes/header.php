<div class="sombra">
    <header class="header-header contenedor">
        <a href="../index.php"><img class="header__logo" src="../img/logo.png" alt="logo Safe Truck"></a>
        <nav class="header__nav">
            <ul class="nav__lista">
                <li class="lista__item"><a href="servicio.php">Servicio</a></li>
                <li class="lista__item"><a href="contacto.php">Contacto</a></li>
                <li class="lista__item"><a href="nosotros.php">Nosotros</a></li>
            </ul>
        </nav>
        <a class="header__btn" href="login.php">Login</a>
    </header>
</div>
