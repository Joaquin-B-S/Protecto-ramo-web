<footer class="footer">
    <div class="contenedor">
        <div class="content-foo">
            <h4>Teléfono</h4>
            <p>+56 978069807</p>
        </div>
        <div class="content-foo">
            <h4>Email</h4>
            <p>safetruck@gmail.com</p>
        </div>
        <div class="content-foo">
            <h4>Ubicación</h4>
            <p>Colón, Talcahuano, Bío Bío</p>
        </div>
        <h2 class="titulo-final">&copy; SafeTruck</h2>
    </div>
</footer>