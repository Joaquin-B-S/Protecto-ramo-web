<?php include('../includes/head.php') ?>
<body>
    <?php include('../includes/header.php') ?>
    <div class="container">
        <form class="form-container">
            <h1 class="form-titulo no-margin">Login</h1>
            <input type="text" placeholder="Usuario">
            <input type="password" placeholder="Contraseña">
            <button type="submit">Login</button>
        </form>
    </div>
    <?php include('../includes/footer.php') ?>
</body>
</html>